import os
import socket

serverIP = '127.0.0.1'
serverPort = 2345

clnt_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clnt_sock.connect((serverIP, serverPort))
print("Connect to Server...")

print("Receiver IP = " + serverIP)
print("Receiver Port = " + str(serverPort))
file_name = input("Input File Name : ")
file_name_11byte = file_name.ljust(11)

file_size = os.path.getsize(file_name)

msg_type_information = '0' 
msg_type_data = '1'

first_msg = msg_type_information.encode() +file_name_11byte.encode() + file_size.to_bytes(4,byteorder = "big")

clnt_sock.send(first_msg)	#처음 메세지 보내기

count = 0

file = open(file_name, "rb")

for i in range(count,file_size):
	
	data = file.read(1024)	#바이트로 반환

	msg = msg_type_data.encode() + file_name_11byte.encode() + file_size.to_bytes(4, byteorder = 'big')

	msg_encode = msg + data

	clnt_sock.send(msg_encode)

	print(clnt_sock.recv(1024).decode('utf-8'))

	count = count + len(data)

	if(count == file_size):
		print(clnt_sock.recv(1024).decode('utf-8'))
		break

file.close()
print("File Send End.")
