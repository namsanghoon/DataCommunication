import struct
import socket
import os
ip_address = '127.0.0.1'
port_number = 2345

server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_sock.bind((ip_address, port_number))
print("Server socket open....")

print("Listening....")
server_sock.listen()

client_sock,addr = server_sock.accept()
first_msg = client_sock.recv(16) 

file_name = first_msg[1:12].decode()
file_size = struct.unpack("!i", first_msg[12:16])[0]
file_path = './recv_dir/' + file_name

print("File Name : " +file_name)
print("File size : "+ str(file_size))
print("File path : ./recv_dir/" + file_name)

file = open("./recv_dir/" + file_name, "wb")
count =0
for i in range(count,file_size):
	msg = client_sock.recv(1040)
	data = msg[16:]

	msg_size = '( current / total size) =' +str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%'	
	print(msg_size)

	file.write(data)
	client_sock.send(msg_size.encode())
	count = count + len(data)
	if(count == file_size):
		msg_size = '( current size / total size) = '+ str(count) + '/'+str(file_size)+ ',' + str(round((count/file_size),5)*100) + '%'
		print(msg_size)
		client_sock.send(msg_size.encode())
		break
file.close()
print("File Receive End.")


