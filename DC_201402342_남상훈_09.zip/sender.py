
import socket
import hashlib
import struct
import os
serverIP = '127.0.0.1'
serverPort = 3333

clnt_sock  = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

print("Sender Socket open...")
print("Receiver IP = " + serverIP)
print("Receiver Port = " + str(serverPort))

file_name = input("Input File Name : ")
print("Send File info(file name, file size, seqNum) to Server...")
print("Start File send")

seqNum=0
window=[]
window_size =4
arr=[0b0000, 0b0001, 0b0010, 0b0011, 0b0100, 0b0101, 0b0110, 0b0111]
index = 0
temp_1 =0
temp_2 =0
ack=0
count=0

file = open(file_name, "rb")
file_size = os.path.getsize(file_name)
file_info = file_size.to_bytes(4, byteorder = "big") + file_name.encode()
temp_1 = seqNum << 4
temp_2 = ack & 0b1111
trans_data = (temp_1|temp_2).to_bytes(1,"big") + file_info 
h = hashlib.sha1()
h.update(trans_data)
file_send = h.digest() + trans_data
window.append(file_send)
clnt_sock.sendto(file_send,(serverIP, serverPort))
flag =0
while True :
	if(flag ==0):
		for i in range(0,window_size):
			data = file.read(1024)
			index = (index +1) % 8
			seqNum = arr[index]
			temp_1 = seqNum << 4
			temp_2 = ack & 0b1111
			trans_data = (temp_1|temp_2).to_bytes(1,"big") + data 
			h = hashlib.sha1()
			h.update(trans_data)
			file_send = h.digest()+trans_data
			window.append(file_send)
			clnt_sock.sendto(file_send,(serverIP,serverPort))
			print('(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
			count = count + len(data)
		flag += 1
		continue
	if(flag==1):
		received_1byte = clnt_sock.recvfrom(1)[0]
		received_ack = struct.unpack("!b", received_1byte[:1])[0] #server���� ���۹��� ACK
		window.remove(file_send)	
		data = file.read(1024)
			index = (index +1) % 8
			seqNum = arr[index]
			temp_1 = seqNum << 4
			temp_2 = ack & 0b1111
			trans_data = (temp_1|temp_2).to_bytes(1,"big") + data 
			h = hashlib.sha1()
			h.update(trans_data)
			file_send = h.digest()+trans_data
			window.append(file_send)
			clnt_sock.sendto(file_send,(serverIP,serverPort))
			print('(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
			count = count + len(data)
	if(count == file_size):
		print('(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
		break

file.close()
print("File Send End.")
