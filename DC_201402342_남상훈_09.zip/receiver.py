
import struct
import socket
import hashlib

ip_address = '127.0.0.1'
port_number = 3333

server_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_sock.bind((ip_address, port_number))
print("Server Socket open....")

print("Send file info ACK...")

data,addr = server_sock.recvfrom(3000) 
checksum = data[0:20]
Data = data[20:]
h = hashlib.sha1()
h.update(Data)


if(checksum == h.digest():
	server_sock.sendto(data[20:21],addr)
	file_size = struct.unpack("!i",data[21:25])[0]
	file_name = data[25:].decode()

print("File Name : " +file_name)
print("File size : "+ str(file_size))
print("File path : ./recv_dir/" + file_name)

file = open("./recv_dir/" + file_name, "wb")
count =0
for i in range(count,file_size):
	data,addr = server_sock.recvfrom(36)
	checksum = data[0:20]
	SeqnumData = data[20:]
	h=hashlib.sha1()
	h.update(SeqnumData)
	hashed_h = h.digest()
	
	if(checksum == hashed_h):
		file.write(data[21:])
		server_sock.sendto(data[20:21], addr)
		print( '(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
		count = count + len(data[21:])
	
	if(count == file_size):
		print( '(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
		break
	
file.close()
print("File Receive End.")


