import socket
import hashlib
import struct
import os
serverIP = '127.0.0.1'
serverPort = 3333

clnt_sock  = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

print("Sender Socket open...")
print("Receiver IP = " + serverIP)
print("Receiver Port = " + str(serverPort))

file_name = input("Input File Name : ")
print("Send File info(file name, file size, seqNum) to Server...")
print("Start File send")

file_size = os.path.getsize(file_name)
file_info = file_size.to_bytes(4, byteorder = "big") + file_name.encode()
seqNum=0
file_checksum = hashlib.sha1()
file_checksum.update(seqNum.to_bytes(1, byteorder="big")+file_info)
h = file_checksum.digest()

file_data = h + seqNum.to_bytes(1, byteorder="big") + file_info
clnt_sock.sendto(file_data,(serverIP, serverPort))

ACK = clnt_sock.recv(4)
ACK_IntValue = struct.unpack("!i" , ACK)

if(((seqNum+1)%2) == ACK_IntValue):
	seqNum = ((seqNum +1) % 2)

count = 0
file = open(file_name, "rb")

for i in range(count,file_size):
	
	data = file.read(1024)

	SeqnumPlusData = seqNum.to_bytes(1,byteorder = "big")+ data

	m = hashlib.sha1()
	m.update(SeqnumPlusData)
	m_encode = m.digest()

	msg_frame = m_encode +seqNum.to_bytes(1, byteorder="big") +data

	clnt_sock.sendto(msg_frame,(serverIP,serverPort))

	ACK = clnt_sock.recv(4)
	ACK_IntValue = struct.unpack("!i",ACK)
	if(((seqNum+1) %2) == ACK_IntValue):
		seqNum = ((seqNum +1)%2)
	print('(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
	count = count + len(data)

	if(count == file_size):
		print('(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
		break

file.close()
print("File Send End.")
