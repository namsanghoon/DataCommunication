import socket
import struct
import re

recv_socket = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))

def convertBytesToMacAddr(bytes_addr):
        mac_addr = ""
        splitedStr = re.findall('..',bytes_addr)

        for i in range(0, len(splitedStr)):
                mac_addr += splitedStr[i]
                if i < len(splitedStr) - 1:
                        mac_addr +=":"

        return mac_addr


while True:
	packet = recv_socket.recvfrom(4096)

	ethernet_header = struct.unpack("!6s6s2s", packet[0][0:14])

	dst_ethernet_addr = ethernet_header[0].hex()
	src_ethernet_addr = ethernet_header[1].hex()
	protocol_type = "0x"+ethernet_header[2].hex()

	print("=====================================================================")
	print("\tEthernet II")
	print("=====================================================================")
	print("Destination MAC address : "+convertBytesToMacAddr(dst_ethernet_addr))
	print("source Mac address: "+convertBytesToMacAddr(src_ethernet_addr))
	print(ethernet_header[2].hex())
	if (ethernet_header[2].hex()) == "0800" :
		while True:
			ip = struct.unpack("!1s1s2s2s2s1s1s2s4s4s",packet[0][14:34])
			version = (ip[0][0]&11110000)>>4
			header_length = (ip[0][0]&15) * 4
			Tos = ip[1].hex()
			TOS = int(Tos,16)
			tl = ip[2].hex()
			TL = int(tl,16)	
			Id = ip[3].hex()
			ID = int(Id,16)
			flag = (ip[4][0]&11100000)>>5
			FO = (ip[4][0]&31)
			ttl = ip[5][0]
			protocol = ip[6][0]
			HC = ip[7].hex()
			hc = int(HC,16)
			print("=====================================================================")
			print("\tIPv4")
			print("=====================================================================")
			print("Version :"+str(version))
			print("Internet Header Length:"+str(header_length))
			print("TOS:"+str(TOS))
			print("Total length:"+str(TL))
			print("Identification:"+str(ID))
			print("Flags :"+str(flag))
			print("Fragment offset:"+str(FO))
			print("TTL:"+str(ttl))
			print("Protocol:"+str(protocol))
			print("Header Checksum:"+str(hc))
			print("Source IP address "+ socket.inet_ntoa(ip[8]))
			print("Destination IP address "+ socket.inet_ntoa(ip[9]))
			ipv4 = 14+header_length
			if protocol == 6 :
				print("======================================================")
				print("\tTCP Header")
				print("======================================================")
				tcp = struct.unpack("!2s2s4s4s1s1s2s2s2s",packet[0][ipv4:ipv4+20])
				SP = tcp[0].hex()
				sp = int(SP,16)
				DP = tcp[1].hex()
				dp = int(DP,16)
				SN = tcp[2].hex()
				sn = int(SN,16)
				AN = tcp[3].hex()
				an = int(AN,16)
				DO = (tcp[4][0]&11110000)>>4
				RS = (tcp[4][0]&14)>>1
				NS = (tcp[4][0]&1)
				cwr = (tcp[5][0]&128)>>7
				ece = (tcp[5][0]&64)>>6
				urg = (tcp[5][0]&32)>>5
				ack = (tcp[5][0]&16)>>4
				psh = (tcp[5][0]&8)>>3
				rst = (tcp[5][0]&4)>>2
				syn = (tcp[5][0]&2)>>1
				fin = tcp[5][0]&1
				WS = tcp[6].hex()
				ws = int(WS,16)
				CS = tcp[7].hex()
				cs = int(CS,16)
				UP = tcp[8].hex()
				up = int(UP,16)
				print("Source Port: "+str(sp))
				print("Destination Port: "+str(dp))
				print("Sequence number : "+str(sn))
				print("Acknowledgment number :"+str(an))
				print("Data offset :"+str(DO))		
				print("Reserver :"+str(RS))
				print("N S : "+str(NS))
				print("CWR : "+str(cwr))
				print("ECE : "+str(ece))
				print("URG : "+str(urg))
				print("ACK : "+str(ack))
				print("PSH : "+str(psh))
				print("RST : "+str(rst))
				print("SYN : "+str(syn))
				print("FIN : "+str(fin))
				print("Window Size : "+str(ws))
				print("Checksum : "+str(cs))
				print("Urgent pointer : "+str(up))

			if protocol == 17 :
				udp = struct.unpack("!2s2s2s2s",packet[0][ipv4:ipv4+8])
				SP = udp[0].hex()
				sp = int(SP,16)
				print("======================================================")
				print("\tUDP Header")
				print("======================================================")
				print("Source Port : "+str(sp))
				DP = udp[1].hex()
				dp = int(DP,16)
				print("Destination Port : "+str(dp))
				UL = udp[2].hex()
				ul = int(UL,16)
				print("UDP Length : "+str(ul))
				UC = udp[3].hex()
				uc = int(UC,16)
				print("UDP Checksum : "+str(uc))
			break
	break
