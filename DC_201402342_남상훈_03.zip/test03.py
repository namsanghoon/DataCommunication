import socket
import struct
import re

recv_socket = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))

def convertBytesToMacAddr(bytes_addr):
        mac_addr = ""
        splitedStr = re.findall('..',bytes_addr)

        for i in range(0, len(splitedStr)):
                mac_addr += splitedStr[i]
                if i < len(splitedStr) - 1:
                        mac_addr +=":"

        return mac_addr


while True:
	packet = recv_socket.recvfrom(4096)

	ethernet_header = struct.unpack("!6s6s2s", packet[0][0:14])

	dst_ethernet_addr = ethernet_header[0].hex()
	src_ethernet_addr = ethernet_header[1].hex()
	protocol_type = "0x"+ethernet_header[2].hex()

	print("=====================================================================")
	print("\tEthernet II")
	print("=====================================================================")
	print("Destination MAC address : "+convertBytesToMacAddr(dst_ethernet_addr))
	print("source Mac address: "+convertBytesToMacAddr(src_ethernet_addr))

	ip = struct.unpack("!1s1s2s2s2s1s1s2s4s4s",packet[0][14:34])
	version = (ip[0][0]&11110000)>>4
	header_length = (ip[0][0]&15) * 4
	Tos = ip[1].hex()
	TOS = int(Tos,16)
	tl = ip[2].hex()
	TL = int(tl,16)	
	Id = ip[3].hex()
	ID = int(Id,16)
	flag = (ip[4][0]&11100000)>>5
	FO = (ip[4][0]&31)
	ttl = ip[5][0]
	protocol = ip[6][0]
	HC = ip[7].hex()
	hc = int(HC,16)
	print("=====================================================================")
	print("\tIPv4")
	print("=====================================================================")
	print("Version :"+str(version))
	print("Internet Header Length:"+str(header_length))
	print("TOS:"+str(TOS))
	print("Total length:"+str(TL))
	print("Identification:"+str(ID))
	print("Flags :"+str(flag))
	print("Fragment offset:"+str(FO))
	print("TTL:"+str(ttl))
	print("Protocol:"+str(protocol))
	print("Header Checksum:"+str(hc))
	print("Source IP address "+ socket.inet_ntoa(ip[8]))
	print("Destination IP address "+ socket.inet_ntoa(ip[9]))
	break

