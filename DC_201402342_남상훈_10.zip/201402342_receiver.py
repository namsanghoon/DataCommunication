
import struct
import socket
import hashlib

ip_address = '127.0.0.1'
port_number = 3333

server_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_sock.bind((ip_address, port_number))
print("Server Socket open....")



data,addr = server_sock.recvfrom(3000) 
checksum = data[0:20]
Data = data[20:]
h = hashlib.sha1()
h.update(Data)
file_size=0
count=0
number=1
while True:
	if checksum == h.digest():
		if file_size==0:
			server_sock.sendto(data[20:21],addr)
			file_size = struct.unpack("!i",data[21:25])[0]
			file_name = data[25:].decode()

			print("File Name : " +file_name)
			print("File size : "+ str(file_size))
			print("File path : ./recv_dir/" + file_name)
			file = open("./recv_dir/" + file_name, "wb")

		else:
			if number%10==0:
				time.sleep(5)
			data,addr = server_sock.recvfrom(36)
			checksum = data[0:20]
			SeqnumData = data[20:]
			h=hashlib.sha1()
			h.update(SeqnumData)
			hashed_h = h.digest()
			seqNum=struct.unpack("!1B",data[20:21])[0]
			seqNum = seqNum>>4
			seqNum = seqNum&0b1111
			if checksum == hashed_h:
				file.write(data[21:])
				server_sock.sendto(data[20:21], addr)
				number = (number+1)%8
				print( '(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
				count = count + len(data[21:])
			else:
				print("Send NAK")
				temp = 0b1111
				ACK = temp
				temp = temp <<4
				ACK = ACK & 0b1111
				send = (temp|ACK).to_bytes(1,byteorder="big")
				server_sock.sendto(send,addr)
			if(count == file_size):
				print( '(current size / total size) =' + str(count)+'/'+str(file_size)+','+str(round((count/file_size),5) * 100) + '%')
				break
	
file.close()
print("File Receive End.")


