import socket

ip_address = '127.0.0.1'
port_number = 3333

server_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_sock.bind((ip_address, port_number))
print("Server socket open...")
data,addr = server_sock.recvfrom(5000)
a = data.decode()
Type = a[0]
msg = a[1:]
print("Type of Message :"+ Type)
print("Received Message from client :"+msg)
if Type == "0" :
	print("Converted Message : "+msg.upper())
	string = msg.upper() 	
elif Type =="1" :
	print("Converted Message : "+msg.lower())
	string = msg.lower()
elif Type =="2" :
	print("Converted Message : "+msg.swapcase())
	string = msg.swapcase()
elif Type == "3" :
	msg = msg[::-1]
	print("Converted Message : "+msg)
	string = msg
server_sock.sendto(string.encode(), addr)
print("Send to Client Converted Message")

