import struct

file = open("studentinfo.txt","rb")
list = []
while True:
    
    dic={}
    data = file.read(1)
    if not data: break
    hakbun = struct.unpack("!1b",data)[0]
    dic['number']=hakbun

    data=file.read(9)
    name = data.decode("utf-8")
    dic['Name']=name

    data=file.read(2)
    score = struct.unpack("!h",data)[0]
    dic['Score']=score

    data=file.read(4)
    age = struct.unpack("!i",data)[0]
    dic['Age'] =age
    list.append(dic)
#a
print("김씨들의 평균나이는?")
sum =0
i =0
for x in range(0,45):
   if list[x]['Name'][0] == "김":
    i = i + 1
    sum = sum + list[x]['Age']
print(sum/i)

#b
print("이씨들 중 나이가 제일 많은 사람은?")
max=0
for x in range(0,45):
   if list[x]['Name'][0] == "이":
    if(list[x]['Age'] >= max):
      max = list[x]['Age']
      temp = x
print(list[temp]['Name'])

#c
a=b=c=d=e=f=g=h=i=j=k=0
number = [] 
for x in range(0,45):
   if list[x]['number'] == 8:
    a = a + 1
   if list[x]['number']==9:
    b = b + 1
   if list[x]['number']==10:
    c = c + 1
   if list[x]['number']==11:
    d = d + 1
   if list[x]['number']==12:
    e = e + 1
   if list[x]['number']==13:
    f = f + 1
   if list[x]['number']==14:
    g = g + 1
   if list[x]['number']==15:
    h = h + 1
   if list[x]['number']==16:
    i = i + 1
   if list[x]['number']==17:
    j= j + 1
   if list[x]['number']==18:
    k= k + 1
number.append(a) 
number.append(b)
number.append(c)
number.append(d)
number.append(e)
number.append(f)
number.append(g)
number.append(h)
number.append(i)
number.append(j)
number.append(k)
count=0
hakbun=8
print("각 학번 별 인원 수는?")
while count < 12:
   if hakbun < 19 :
     print(hakbun,"학번은",number[count])
     count = count+1
     hakbun = hakbun+1
   
  

     




